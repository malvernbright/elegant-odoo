To configure the product follow this steps:

1.  Go to a product form.
2.  Go to *Inventory* tab.
3.  Check the box *Purchase Request* along with the route *Buy*.

With this configuration, whenever a procurement order is created and the
supply rule selected is 'Buy' the application will create a Purchase
Request instead of a Purchase Order.

When editing the 'purchase request' form and choosing the 'requested_by' field
the requester's department will be automatically set.

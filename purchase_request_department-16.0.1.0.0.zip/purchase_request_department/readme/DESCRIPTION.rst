This module adds the user department in a new field in the purchase request
form and allows to group by department on the tree view.
